import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import mysql.connector

app = Flask(__name__)
CORS(app)

# Configuración de la carpeta para subir imágenes
UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Configuración de conexión a MySQL de XAMPP
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',  # En XAMPP la contraseña por defecto de root es vacía
    'database': 'instagram_clone',
    'port': 3306
}

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# --- RUTAS DE AUTENTICACIÓN ---

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not email or not password:
        return jsonify({'error': 'Faltan campos obligatorios'}), 400

    hashed_password = generate_password_hash(password)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "INSERT INTO usuarios (username, email, password_hash) VALUES (%s, %s, %s)"
        cursor.execute(query, (username, email, hashed_password))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'message': 'Usuario registrado con éxito'}), 201
    except mysql.connector.Error as err:
        if err.errno == 1062:  # Código de error para duplicados (UNIQUE)
            return jsonify({'error': 'El nombre de usuario o correo ya existe'}), 409
        return jsonify({'error': str(err)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    query = "SELECT * FROM usuarios WHERE username = %s"
    cursor.execute(query, (username,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user and check_password_hash(user['password_hash'], password):
        return jsonify({
            'message': 'Autenticación exitosa',
            'user': {'id': user['id_usuario'], 'username': user['username']}
        }), 200

    return jsonify({'error': 'Credenciales inválidas'}), 401

# --- RUTAS DE PUBLICACIONES Y ARCHIVOS ---

@app.route('/api/posts', methods=['GET'])
def get_posts():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    query = """
        SELECT p.id_publicacion, p.descripcion, p.imagen_url, p.fecha_creacion, u.username,
               (SELECT COUNT(*) FROM likes l WHERE l.id_publicacion = p.id_publicacion) AS likes
        FROM publicaciones p
        JOIN usuarios u ON p.id_usuario = u.id_usuario
        ORDER BY p.fecha_creacion DESC
    """
    cursor.execute(query)
    posts = cursor.fetchall()
    cursor.close()
    conn.close()

    return jsonify(posts), 200

@app.route('/api/posts', methods=['POST'])
def create_post():
    if 'image' not in request.files:
        return jsonify({'error': 'Se requiere una imagen'}), 400

    file = request.files['image']
    id_usuario = request.form.get('id_usuario')
    descripcion = request.form.get('descripcion', '')

    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Formato de imagen no permitido'}), 400

    filename = secure_filename(file.filename)
    saved_filename = f"{id_usuario}_{filename}"
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], saved_filename)
    file.save(file_path)

    imagen_url = f"/uploads/{saved_filename}"

    conn = get_db_connection()
    cursor = conn.cursor()
    query = "INSERT INTO publicaciones (id_usuario, descripcion, imagen_url) VALUES (%s, %s, %s)"
    cursor.execute(query, (id_usuario, descripcion, imagen_url))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'message': 'Publicación creada exitosamente'}), 201

@app.route('/api/posts/<int:id_publicacion>/like', methods=['POST'])
def toggle_like(id_publicacion):
    data = request.json
    id_usuario = data.get('id_usuario')

    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Verificar si el usuario ya dio like
    cursor.execute("SELECT id_like FROM likes WHERE id_publicacion = %s AND id_usuario = %s", (id_publicacion, id_usuario))
    like_existente = cursor.fetchone()

    if like_existente:
        cursor.execute("DELETE FROM likes WHERE id_publicacion = %s AND id_usuario = %s", (id_publicacion, id_usuario))
    else:
        cursor.execute("INSERT INTO likes (id_publicacion, id_usuario) VALUES (%s, %s)", (id_publicacion, id_usuario))
    
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({'message': 'Like actualizado'}), 200

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# -------------------------------------------------------------------
# PERFIL DE USUARIO
# -------------------------------------------------------------------

@app.route('/api/users/<int:user_id>', methods=['GET'])
def get_user_profile(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT id_usuario, username, email, biografia, avatar_url, fecha_registro FROM usuarios WHERE id_usuario = %s",
        (user_id,)
    )
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    if not user:
        return jsonify({'error': 'Usuario no encontrado'}), 404
    return jsonify(user), 200

@app.route('/api/users/<int:user_id>', methods=['PUT', 'POST'])
def update_user_profile(user_id):
    biografia = request.form.get('biografia', '')
    avatar_file = request.files.get('avatar')
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    avatar_url = None
    if avatar_file:
        filename = secure_filename(f"avatar_{user_id}_{avatar_file.filename}")
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        avatar_file.save(filepath)
        avatar_url = f"/uploads/{filename}"

    if avatar_url:
        cursor.execute(
            "UPDATE usuarios SET biografia = %s, avatar_url = %s WHERE id_usuario = %s",
            (biografia, avatar_url, user_id)
        )
    else:
        cursor.execute(
            "UPDATE usuarios SET biografia = %s WHERE id_usuario = %s",
            (biografia, user_id)
        )
        
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'message': 'Perfil actualizado correctamente', 'avatar_url': avatar_url}), 200

# -------------------------------------------------------------------
# AMISTADES & SOLICITUDES
# -------------------------------------------------------------------

@app.route('/api/friends/request', methods=['POST'])
def send_friend_request():
    data = request.json
    id_solicitante = data.get('id_solicitante')
    id_receptor = data.get('id_receptor')

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO amistades (id_solicitante, id_receptor, estado) VALUES (%s, %s, 'pendiente')",
            (id_solicitante, id_receptor)
        )
        id_amistad = cursor.lastrowid
        
        # Generar Notificación
        cursor.execute(
            "INSERT INTO notificaciones (id_usuario, id_emisor, tipo, referencia_id) VALUES (%s, %s, 'solicitud_amistad', %s)",
            (id_receptor, id_solicitante, id_amistad)
        )
        conn.commit()
        return jsonify({'message': 'Solicitud enviada'}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'error': 'Ya existe una solicitud o relación activa'}), 400
    finally:
        cursor.close()
        conn.close()

# -------------------------------------------------------------------
# NOTIFICACIONES
# -------------------------------------------------------------------

@app.route('/api/notifications/<int:user_id>', methods=['GET'])
def get_notifications(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    query = """
        SELECT n.id_notificacion, n.tipo, n.leido, n.fecha_creacion,
               u.username AS emisor_username, u.avatar_url AS emisor_avatar
        FROM notificaciones n
        JOIN usuarios u ON n.id_emisor = u.id_usuario
        WHERE n.id_usuario = %s
        ORDER BY n.fecha_creacion DESC
    """
    cursor.execute(query, (user_id,))
    notifications = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(notifications), 200

# --- EJECUCIÓN DE LA APLICACIÓN ---

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)