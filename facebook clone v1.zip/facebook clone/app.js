document.addEventListener("DOMContentLoaded", () => {
    const API_URL = "http://localhost:5000/api";
    const SERVER_URL = "http://localhost:5000";

    // Elementos DOM Autenticación y Layout
    const authSection = document.getElementById("auth-section");
    const mainApp = document.getElementById("main-app");
    const tabLogin = document.getElementById("tab-login");
    const tabRegister = document.getElementById("tab-register");
    const loginForm = document.getElementById("login-form");
    const registerForm = document.getElementById("register-form");
    const authMessage = document.getElementById("auth-message");
    const userSessionInfo = document.getElementById("user-session-info");
    const sessionUsername = document.getElementById("session-username");
    const avatarInitials = document.getElementById("avatar-initials");
    const logoutBtn = document.getElementById("logout-btn");

    // Elementos DOM Publicaciones
    const postForm = document.getElementById("post-form");
    const postsContainer = document.getElementById("posts-container");
    const imageInput = document.getElementById("image-input");
    const fileChosenName = document.getElementById("file-chosen-name");

    // Elementos DOM Vistas y Navegación
    const navFeed = document.getElementById("nav-feed");
    const navProfile = document.getElementById("nav-profile");
    const navNotifications = document.getElementById("nav-notifications");
    const feedView = document.getElementById("feed-view");
    const profileView = document.getElementById("profile-view");
    const notificationsView = document.getElementById("notifications-view");
    const profileForm = document.getElementById("profile-form");
    const bioInput = document.getElementById("bio-input");
    const avatarInput = document.getElementById("avatar-input");
    const notificationsContainer = document.getElementById("notifications-container");


    
    // Estado de Sesión
    let currentUser = JSON.parse(localStorage.getItem("user")) || null;

    checkSession();
    function getImageUrl(path) {
    if (!path) return "placeholder.png"; // O la ruta a tu imagen por defecto
    if (path.startsWith("http")) return path;
    return `${SERVER_URL}${path}`;
    }
    // Gestor de Navegación Lateral
    function switchTab(activeNav, activeView) {
        [navFeed, navProfile, navNotifications].forEach(nav => nav.classList.remove("active"));
        [feedView, profileView, notificationsView].forEach(view => view.classList.add("hidden"));

        activeNav.classList.add("active");
        activeView.classList.remove("hidden");
    }

    navFeed.addEventListener("click", (e) => {
        e.preventDefault();
        switchTab(navFeed, feedView);
        loadPosts();
    });

    navProfile.addEventListener("click", (e) => {
        e.preventDefault();
        switchTab(navProfile, profileView);
        loadUserProfile();
    });

    navNotifications.addEventListener("click", (e) => {
        e.preventDefault();
        switchTab(navNotifications, notificationsView);
        loadNotifications();
    });

    // Control de Nombre de Archivo Adjunto
    if (imageInput && fileChosenName) {
        imageInput.addEventListener("change", (e) => {
            const fileName = e.target.files[0] ? e.target.files[0].name : "Sin archivo";
            fileChosenName.textContent = fileName;
        });
    }

    // Pestañas Login / Registro
    tabLogin.addEventListener("click", () => {
        tabLogin.classList.add("active");
        tabRegister.classList.remove("active");
        loginForm.classList.remove("hidden");
        registerForm.classList.add("hidden");
        authMessage.textContent = "";
    });

    tabRegister.addEventListener("click", () => {
        tabRegister.classList.add("active");
        tabLogin.classList.remove("active");
        registerForm.classList.remove("hidden");
        loginForm.classList.add("hidden");
        authMessage.textContent = "";
    });

    // Evento Registro
    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const username = document.getElementById("reg-username").value;
        const email = document.getElementById("reg-email").value;
        const password = document.getElementById("reg-password").value;

        try {
            const res = await fetch(`${API_URL}/register`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, email, password })
            });

            const data = await res.json();
            if (res.ok) {
                authMessage.style.color = "green";
                authMessage.textContent = "Registro exitoso. Inicia sesión.";
                registerForm.reset();
                tabLogin.click();
            } else {
                authMessage.style.color = "red";
                authMessage.textContent = data.error || "Error al registrar.";
            }
        } catch (err) {
            authMessage.style.color = "red";
            authMessage.textContent = "No hay conexión con el servidor.";
        }
    });
    function renderUserProfile(user) {
    const avatarImg = document.getElementById("profile-avatar"); // Cambia por tu ID real
    const usernameText = document.getElementById("profile-username");
    const bioInput = document.getElementById("bio-input");

    if (avatarImg) {
        avatarImg.src = getImageUrl(user.avatar_url);
    }
    if (usernameText) usernameText.textContent = user.username;
    if (bioInput) bioInput.value = user.biografia || "";
    }
    // Evento Login
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const username = document.getElementById("login-username").value;
        const password = document.getElementById("login-password").value;

        try {
            const res = await fetch(`${API_URL}/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });

            const data = await res.json();
            if (res.ok) {
                currentUser = data.user;
                localStorage.setItem("user", JSON.stringify(currentUser));
                loginForm.reset();
                checkSession();
            } else {
                authMessage.style.color = "red";
                authMessage.textContent = data.error || "Credenciales incorrectas.";
            }
        } catch (err) {
            authMessage.style.color = "red";
            authMessage.textContent = "No hay conexión con el servidor.";
        }
    });

    // Cerrar Sesión
    logoutBtn.addEventListener("click", () => {
        localStorage.removeItem("user");
        currentUser = null;
        checkSession();
    });

    // Validar Estado de Sesión
    function checkSession() {
        if (currentUser) {
            authSection.classList.add("hidden");
            mainApp.classList.remove("hidden");
            userSessionInfo.classList.remove("hidden");
            sessionUsername.textContent = `@${currentUser.username}`;
            if (avatarInitials) {
                avatarInitials.textContent = currentUser.username.charAt(0).toUpperCase();
            }
            switchTab(navFeed, feedView);
            loadPosts();
        } else {
            authSection.classList.remove("hidden");
            mainApp.classList.add("hidden");
            userSessionInfo.classList.add("hidden");
        }
    }

    // Crear Publicación
    postForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const content = document.getElementById("content-input").value;
        const imageFile = imageInput.files[0];

        if (!imageFile) {
            alert("Debes seleccionar una imagen.");
            return;
        }

        const formData = new FormData();
        formData.append("id_usuario", currentUser.id);
        formData.append("descripcion", content);
        formData.append("image", imageFile);

        try {
            const res = await fetch(`${API_URL}/posts`, {
                method: "POST",
                body: formData
            });

            if (res.ok) {
                postForm.reset();
                if (fileChosenName) fileChosenName.textContent = "Sin archivo";
                loadPosts();
            } else {
                const data = await res.json();
                alert(data.error || "Error al crear la publicación.");
            }
        } catch (err) {
            alert("Error al enviar la publicación al servidor.");
        }
    });

    // Cargar Publicaciones Feed
    async function loadPosts() {
        try {
            const res = await fetch(`${API_URL}/posts`);
            const posts = await res.json();

            postsContainer.innerHTML = "";
            if (!posts || posts.length === 0) {
                postsContainer.innerHTML = "<p>No hay publicaciones aún.</p>";
                return;
            }

            posts.forEach(post => {
                const initial = post.username ? post.username.charAt(0).toUpperCase() : "U";
                const formattedDate = post.fecha_creacion 
                    ? new Date(post.fecha_creacion).toLocaleDateString() 
                    : "";

                const postElement = document.createElement("article");
                postElement.className = "post-card";
                postElement.innerHTML = `
                    <div class="post-header-user">
                        <div class="avatar-sm">${initial}</div>
                        <div class="post-user-info">
                            <span class="post-username">@${escapeHTML(post.username || "usuario")}</span>
                            <span class="post-time">${formattedDate}</span>
                        </div>
                    </div>
                    <div class="post-image-container">
                        <img src="http://localhost:5000${post.imagen_url}" alt="Publicación">
                    </div>
                    <div class="post-body">
                        <p class="post-description">${escapeHTML(post.descripcion || "")}</p>
                    </div>
                    <div class="post-footer-actions">
                        <button class="btn btn-secondary btn-sm" onclick="addLike(${post.id_publicacion})">
                            👍 Me gusta (${post.likes || 0})
                        </button>
                    </div>
                `;
                postsContainer.appendChild(postElement);
            });
        } catch (err) {
            console.error("Error al cargar publicaciones:", err);
            postsContainer.innerHTML = "<p>Error al cargar el feed.</p>";
        }
    }

    // Perfil de Usuario
    // Cargar perfil del usuario actual
    async function loadUserProfile() {
        if (!currentUser) return;
        
        // Determinar ID compatible
        const userId = currentUser.id || currentUser.id_usuario;
        if (!userId) return;

        try {
            const res = await fetch(`${API_URL}/users/${userId}`);
            if (res.ok) {
                const data = await res.json();
                bioInput.value = data.biografia || "";
            }
        } catch (err) {
            console.error("Error al obtener datos del perfil:", err);
        }
    }

    // Guardar cambios del perfil
    profileForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!currentUser) return;

    const userId = currentUser.id || currentUser.id_usuario;
    const formData = new FormData();
    formData.append("biografia", bioInput.value);
    
    if (avatarInput.files[0]) {
        formData.append("avatar", avatarInput.files[0]);
    }

    try {
        const res = await fetch(`${API_URL}/users/${userId}`, {
            method: "POST",
            body: formData
        });

        const data = await res.json();

        if (res.ok) {
            alert(data.message);
            
            // Actualizar el estado local con la nueva URL de la imagen
            if (data.avatar_url) {
                currentUser.avatar_url = data.avatar_url;
            }
            currentUser.biografia = bioInput.value;

            // Refrescar el elemento <img> inmediatamente
            const avatarImg = document.getElementById("profile-avatar");
            if (avatarImg && data.avatar_url) {
                avatarImg.src = getImageUrl(data.avatar_url);
            }
            
            // Si guardas la sesión en localStorage:
            localStorage.setItem("user", JSON.stringify(currentUser));
        } else {
            alert(data.error || "Error al actualizar perfil");
        }
    } catch (err) {
        console.error("Error al actualizar perfil:", err);
        alert("Error de conexión al guardar los cambios.");
    }
    });

    // Notificaciones
    async function loadNotifications() {
        if (!currentUser) return;
        try {
            const res = await fetch(`${API_URL}/notifications/${currentUser.id}`);
            const data = await res.json();

            notificationsContainer.innerHTML = "";
            if (!data || data.length === 0) {
                notificationsContainer.innerHTML = "<p>No tienes notificaciones pendientes.</p>";
                return;
            }

            data.forEach(item => {
                const notifEl = document.createElement("div");
                notifEl.className = "card";
                notifEl.style.padding = "10px 14px";
                notifEl.style.marginBottom = "8px";

                let mensaje = "Tienes una nueva interacción.";
                if (item.tipo === "solicitud_amistad") {
                    mensaje = `@${escapeHTML(item.emisor_username)} te ha enviado una solicitud de amistad.`;
                } else if (item.tipo === "like") {
                    mensaje = `@${escapeHTML(item.emisor_username)} le dio Me gusta a tu publicación.`;
                }

                notifEl.innerHTML = `
                    <p style="font-size: 0.9rem;">${mensaje}</p>
                    <span style="font-size: 0.75rem; color: var(--text-secondary);">${new Date(item.fecha_creacion).toLocaleString()}</span>
                `;
                notificationsContainer.appendChild(notifEl);
            });
        } catch (err) {
            console.error("Error al cargar notificaciones:", err);
            notificationsContainer.innerHTML = "<p>Error al obtener notificaciones.</p>";
        }
    }

    // Funciones en Ámbito Global
    window.addLike = async function(id_publicacion) {
        if (!currentUser) return;
        try {
            await fetch(`${API_URL}/posts/${id_publicacion}/like`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ id_usuario: currentUser.id })
            });
            loadPosts();
        } catch (err) {
            console.error("Error al registrar like:", err);
        }
    };

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }
});